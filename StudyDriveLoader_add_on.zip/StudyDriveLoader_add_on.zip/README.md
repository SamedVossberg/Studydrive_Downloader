This is a StudyDrive loader extension for Chrome. 
When activated, the button on the website will turn green and will enable downloads just as when there was no pay wall.